from django.contrib import admin
from django.urls import path
from quiz import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.start_quiz, name='start_quiz'),
    path('submit_answer/<int:question_id>/', views.submit_answer, name='submit_answer'),
    path('results/', views.view_results, name='view_results'),
]

