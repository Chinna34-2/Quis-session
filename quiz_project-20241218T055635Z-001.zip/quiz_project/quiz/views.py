import random
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Question, Answer
from .forms import AnswerForm

def start_quiz(request):
    # Fetch a random question
    question = random.choice(Question.objects.all())
    return render(request, 'quiz/question.html', {'question': question})

def submit_answer(request, question_id):
    question = Question.objects.get(id=question_id)
    user_answer = request.POST.get('answer')

    # Check if the answer is correct
    is_correct = user_answer == question.correct_answer

    # Save the answer
    Answer.objects.create(question=question, user_answer=user_answer, is_correct=is_correct)

    # Redirect to the next question or show results
    next_question = random.choice(Question.objects.all())
    return render(request, 'quiz/question.html', {'question': next_question})

def view_results(request):
    answers = Answer.objects.all()
    total_questions = answers.count()
    correct_answers = answers.filter(is_correct=True).count()
    incorrect_answers = total_questions - correct_answers
    return render(request, 'quiz/results.html', {
        'total_questions': total_questions,
        'correct_answers': correct_answers,
        'incorrect_answers': incorrect_answers
    })

